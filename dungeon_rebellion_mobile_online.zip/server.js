const express = require("express");
const http = require("http");
const { Server } = require("socket.io");
const crypto = require("crypto");

const app = express();
const server = http.createServer(app);
const io = new Server(server);
app.use(express.static("public"));
app.get("/healthz", (_req, res) => res.status(200).json({ ok: true, app: "dungeon-rebellion" }));

const rooms = new Map();
const MAX_PLAYERS = 5;
const MIN_PLAYERS = 2;

const cardPool = [
  { id:"spark", name:"Funkenstoß", icon:"🔥", type:"MAGIE", desc:"Erhalte 1 Licht.", action:"light", amount:1, color:"ember" },
  { id:"shadow", name:"Schattenmantel", icon:"🌑", type:"TRICK", desc:"Schütze dich vor dem nächsten Angriff.", action:"shield", color:"violet" },
  { id:"steal", name:"Taschendieb", icon:"🗡️", type:"VERRAT", desc:"Stiehl einem Rivalen 1 Licht.", action:"steal", color:"blood" },
  { id:"blast", name:"Runenexplosion", icon:"💥", type:"MAGIE", desc:"Ein Rivale verliert 1 Licht.", action:"blast", color:"ember" },
  { id:"scout", name:"Finsternis lesen", icon:"👁️", type:"ERKUNDUNG", desc:"Gehe 2 Felder vor.", action:"move", amount:2, color:"teal" },
  { id:"heal", name:"Seelenfunke", icon:"✨", type:"MAGIE", desc:"Erhalte 2 Licht.", action:"light", amount:2, color:"teal" },
  { id:"trap", name:"Falsche Fährte", icon:"🕸️", type:"VERRAT", desc:"Ein Rivale rutscht 1 Feld zurück.", action:"sabotage", color:"blood" },
  { id:"blade", name:"Kristallklinge", icon:"⚔️", type:"KAMPF", desc:"Gehe 1 Feld vor und erhalte 1 Licht.", action:"combo", color:"gold" },
  { id:"torch", name:"Letzte Fackel", icon:"🏮", type:"LICHT", desc:"Erhalte 3 Licht.", action:"light", amount:3, color:"gold" },
  { id:"portal", name:"Riss im Schleier", icon:"🌀", type:"ERKUNDUNG", desc:"Gehe 3 Felder vor.", action:"move", amount:3, color:"violet" }
];

const dungeon = [
  { name:"Spinnennest", icon:"🕷️", text:"Giftige Fäden! Zahle 1 Licht oder bleibe stehen.", kind:"choice" },
  { name:"Verfluchte Truhe", icon:"🧰", text:"Würfle dein Glück: 1–3: −1 Licht, 4–6: +1 Licht.", kind:"roll" },
  { name:"Hungriger Schleim", icon:"🟢", text:"Der Schleim verschlingt deine Fackel: −1 Licht.", kind:"dark" },
  { name:"Runenaltar", icon:"🔮", text:"Alte Magie: +1 Licht.", kind:"light" },
  { name:"Drachenhauch", icon:"🐉", text:"Weiche zurück oder verliere 2 Licht.", kind:"choice" },
  { name:"Knochenbrücke", icon:"💀", text:"Würfle: bei 1–2 −1 Feld, sonst +1 Feld.", kind:"roll" },
  { name:"Verlorene Vorräte", icon:"🎒", text:"Du findest eine Fackel: +1 Licht.", kind:"light" },
  { name:"Geisterwache", icon:"👻", text:"Ein Geist blockiert den Weg: −1 Licht.", kind:"dark" }
];

function shuffled(arr) {
  const a = [...arr];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}
function code() { return crypto.randomBytes(3).toString("hex").toUpperCase(); }
function playerPublic(p) {
  return { id:p.id, name:p.name, pos:p.pos, light:p.light, alive:p.alive, legion:p.legion, connected:p.connected, shield:p.shield };
}
function stateFor(room, socketId) {
  const me = room.players.find(p => p.id === socketId);
  return {
    code: room.code,
    started: room.started,
    players: room.players.map(playerPublic),
    current: room.current,
    turn: room.turn,
    path: room.path,
    log: room.log.slice(-8),
    hand: me ? me.hand : [],
    myId: socketId,
    winner: room.winner,
    exits: room.exits
  };
}
function sendRoom(room) {
  for (const p of room.players) io.to(p.id).emit("state", stateFor(room, p.id));
}
function say(room, message) {
  room.log.push(message);
  room.log = room.log.slice(-30);
}
function alivePlayers(room) { return room.players.filter(p => p.alive && !p.legion); }
function nextTurn(room) {
  if (room.winner) return;
  for (let tries=0; tries<room.players.length; tries++) {
    room.current = (room.current + 1) % room.players.length;
    const p = room.players[room.current];
    if (p.alive && p.connected) { room.turn++; return; }
  }
}
function eliminateIfDark(room, p) {
  if (p.light <= 0 && p.alive && !p.legion) {
    p.light = 0; p.legion = true;
    say(room, `💀 ${p.name} ist der Skelettarmee beigetreten! Jetzt jagt ${p.name} die Lebenden.`);
  }
}
function drawHand(p) {
  p.hand = shuffled(cardPool).slice(0, 4).map(c => ({...c, uid:crypto.randomBytes(4).toString("hex")}));
}
function endIfDone(room) {
  if (room.winner) return true;
  if (alivePlayers(room).length === 0) {
    room.winner = { name:"Die Skelettarmee", id:null };
    say(room, "💀 Niemand entkommt. Der Dungeon-Lord gewinnt!");
    return true;
  }
  return false;
}
function resolveTile(room, p) {
  if (p.pos >= room.path.length - 1) {
    room.winner = { name:p.name, id:p.id };
    say(room, `🏆 ${p.name} hat den Ausgang erreicht und entkommt dem Dungeon!`);
    return;
  }
  const tile = room.path[p.pos];
  say(room, `${tile.icon} ${p.name} betritt: ${tile.name}. ${tile.text}`);
  if (tile.kind === "dark") p.light -= 1;
  if (tile.kind === "light") p.light += 1;
  if (tile.kind === "roll") {
    const r = 1 + Math.floor(Math.random()*6);
    say(room, `🎲 ${p.name} würfelt eine ${r}.`);
    if (tile.name === "Verfluchte Truhe") p.light += r >= 4 ? 1 : -1;
    else p.pos += r <= 2 ? -1 : 1;
  }
  if (tile.kind === "choice") {
    // Online prototype resolves choices automatically to keep turns flowing.
    if (tile.name === "Drachenhauch") { p.light -= 2; say(room, "Der Drache versengt die Fackel."); }
    else p.light -= 1;
  }
  p.pos = Math.max(0, Math.min(room.path.length-1, p.pos));
  p.light = Math.min(6, p.light);
  eliminateIfDark(room, p);
  if (p.pos >= room.path.length - 1 && p.alive && !p.legion) {
    room.winner = {name:p.name,id:p.id};
    say(room, `🏆 ${p.name} entkommt als Erste:r!`);
  }
}
function createRoom(socket, name) {
  const c = code();
  const room = { code:c, players:[], started:false, current:0, turn:0, path:[], log:[], winner:null, exits:["🌒 Mondtor","🔥 Aschepforte","🗝️ Königssiegel"] };
  room.players.push({id:socket.id,name:name.slice(0,18),pos:0,light:4,alive:true,legion:false,connected:true,shield:false,hand:[],room:c});
  drawHand(room.players[0]);
  rooms.set(c, room);
  socket.join(c);
  say(room, `🕯️ Raum ${c} wurde erschaffen. Warte auf Mitspieler.`);
  socket.emit("joined", {code:c});
  sendRoom(room);
}
io.on("connection", socket => {
  socket.on("create", name => createRoom(socket, String(name||"Abenteurer").trim()||"Abenteurer"));
  socket.on("join", ({code:c,name}) => {
    const room = rooms.get(String(c||"").toUpperCase());
    if (!room) return socket.emit("errorMessage","Diesen Raum gibt es nicht.");
    if (room.started) return socket.emit("errorMessage","Die Runde läuft bereits.");
    if (room.players.length >= MAX_PLAYERS) return socket.emit("errorMessage","Der Raum ist voll (max. 5 Spieler).");
    const clean = String(name||"Abenteurer").trim().slice(0,18) || "Abenteurer";
    if (room.players.some(p=>p.name.toLowerCase()===clean.toLowerCase())) return socket.emit("errorMessage","Dieser Name ist schon vergeben.");
    room.players.push({id:socket.id,name:clean,pos:0,light:4,alive:true,legion:false,connected:true,shield:false,hand:[],room:room.code});
    drawHand(room.players[room.players.length-1]);
    socket.join(room.code);
    say(room, `⚔️ ${clean} betritt den Dungeon.`);
    socket.emit("joined",{code:room.code});
    sendRoom(room);
  });
  socket.on("startGame", () => {
    const room = [...rooms.values()].find(r=>r.players.some(p=>p.id===socket.id));
    if (!room) return;
    if (room.started) return;
    if (room.players.length < MIN_PLAYERS) return socket.emit("errorMessage","Zum Starten braucht ihr mindestens 2 Spieler.");
    room.started = true; room.current = 0; room.turn = 1;
    room.path = shuffled(dungeon).concat([{name:"Ausgang",icon:"🚪",text:"Freiheit liegt vor dir!",kind:"exit"}]);
    // Make the escape path seven moves away, with unique original encounter cards.
    room.path = room.path.slice(0,7).concat([{name:"Letzte Schwelle",icon:"🌌",text:"Der Ausgang ist zum Greifen nah.",kind:"light"},{name:"Ausgang",icon:"🚪",text:"Freiheit!",kind:"exit"}]);
    say(room, "🗺️ Der Dungeon öffnet sich. Wer zuerst entkommt, gewinnt!");
    sendRoom(room);
  });
  socket.on("playCard", ({uid,targetId}) => {
    const room = [...rooms.values()].find(r=>r.players.some(p=>p.id===socket.id));
    if (!room || !room.started || room.winner) return;
    const p = room.players.find(x=>x.id===socket.id);
    if (!p || room.players[room.current]?.id !== p.id || !p.alive || p.legion) return socket.emit("errorMessage","Du bist gerade nicht am Zug.");
    const idx = p.hand.findIndex(c=>c.uid===uid);
    if (idx<0) return;
    const card = p.hand.splice(idx,1)[0];
    const target = room.players.find(x=>x.id===targetId && x.id!==p.id && x.alive && !x.legion);
    switch(card.action) {
      case "light": p.light = Math.min(6,p.light+card.amount); say(room,`✨ ${p.name} spielt ${card.name} und hat ${p.light} Licht.`); break;
      case "move": p.pos = Math.min(room.path.length-1,p.pos+card.amount); say(room,`🧭 ${p.name} spielt ${card.name} und rückt vor.`); break;
      case "shield": p.shield=true; say(room,`🌑 ${p.name} hüllt sich in einen Schattenmantel.`); break;
      case "steal":
        if (!target) { p.hand.push(card); return socket.emit("errorMessage","Wähle einen gültigen Rivalen."); }
        if (target.shield) { target.shield=false; say(room,`🛡️ ${target.name} blockt den Taschendiebstahl!`); }
        else { target.light=Math.max(0,target.light-1); p.light=Math.min(6,p.light+1); eliminateIfDark(room,target); say(room,`🗡️ ${p.name} stiehlt Licht von ${target.name}.`); }
        break;
      case "blast":
        if (!target) { p.hand.push(card); return socket.emit("errorMessage","Wähle einen gültigen Rivalen."); }
        if (target.shield) { target.shield=false; say(room,`🛡️ ${target.name} blockt die Runenexplosion!`); }
        else { target.light=Math.max(0,target.light-1); eliminateIfDark(room,target); say(room,`💥 ${p.name} trifft ${target.name} mit einer Runenexplosion.`); }
        break;
      case "sabotage":
        if (!target) { p.hand.push(card); return socket.emit("errorMessage","Wähle einen gültigen Rivalen."); }
        if (target.shield) { target.shield=false; say(room,`🛡️ ${target.name} weicht der falschen Fährte aus.`); }
        else { target.pos=Math.max(0,target.pos-1); say(room,`🕸️ ${p.name} lockt ${target.name} auf eine falsche Fährte.`); }
        break;
      case "combo": p.pos=Math.min(room.path.length-1,p.pos+1); p.light=Math.min(6,p.light+1); say(room,`⚔️ ${p.name} spielt ${card.name}.`); break;
    }
    if (p.pos >= room.path.length-1 && p.alive && !p.legion) {
      room.winner={name:p.name,id:p.id}; say(room,`🏆 ${p.name} hat den Ausgang erreicht!`);
    }
    if (p.hand.length < 3) p.hand.push(...shuffled(cardPool).slice(0, 3-p.hand.length).map(c=>({...c,uid:crypto.randomBytes(4).toString("hex")})));
    if (!room.winner) { nextTurn(room); }
    endIfDone(room); sendRoom(room);
  });
  socket.on("explore", () => {
    const room = [...rooms.values()].find(r=>r.players.some(p=>p.id===socket.id));
    if (!room || !room.started || room.winner) return;
    const p=room.players.find(x=>x.id===socket.id);
    if (!p || room.players[room.current]?.id!==p.id || !p.alive || p.legion) return socket.emit("errorMessage","Du bist gerade nicht am Zug.");
    p.pos=Math.min(room.path.length-1,p.pos+1);
    say(room,`🧭 ${p.name} wagt sich ein Feld tiefer in den Dungeon.`);
    resolveTile(room,p);
    if (p.hand.length<4) p.hand.push(...shuffled(cardPool).slice(0,4-p.hand.length).map(c=>({...c,uid:crypto.randomBytes(4).toString("hex")})));
    if (!room.winner) { nextTurn(room); endIfDone(room); }
    sendRoom(room);
  });
  socket.on("disconnect",()=>{
    for(const room of rooms.values()){
      const p=room.players.find(x=>x.id===socket.id);
      if(p){p.connected=false;say(room,`📡 ${p.name} hat die Verbindung verloren.`);sendRoom(room);break;}
    }
  });
});
const port=process.env.PORT||3000;
server.listen(port, "0.0.0.0", ()=>console.log(`Dungeon Rebellion läuft auf Port ${port}`));